package fortunex.menu;

public class Main {
    public static void main(String[] args) {
        // Inicia o menu principal, que cuidará de toda a navegação
        menuPrincipal.iniciar();
    }
}